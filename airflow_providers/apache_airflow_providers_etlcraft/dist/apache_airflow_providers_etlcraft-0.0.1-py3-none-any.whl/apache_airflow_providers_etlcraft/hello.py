def my_hello():
    print("Hello world 4")